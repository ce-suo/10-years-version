# mellow-shader

Simple gameplay-oriented Iris shaderpack meant for low-end computers. Mellow is vivid and colorful and aims to have a similar level of visibility to vanilla.

## Installation
Downloading directly from codeberg is usually not recommended, as the code is more likely to contain bugs.
If you are a regular user, you should download from [Modrinth](https://modrinth.com/shader/mellow) instead.

This shader requires [Iris](https://www.irisshaders.dev/) to function.
1. Click on the "More operations" button (with the three dots), located above the files, on the right.
2. Select "Download as ZIP"
3. Copy the file to your .minecraft/shaderpacks folder
4. Enable it in-game, in Options > Video Settings > Shader Packs

##  Features
- Bloom
- Wavy foliage & water
- Ambient & border fog
- "Realistic" clouds
- Lightmap based shadows
- Handheld lights
- Basic color grading (saturation, exposure, etc)
- Fully adjustable light colors

##   Compatibility
- At the moment only versios 1.17 and up (including 1.20.4) are being tested. Earlier versions may or may not work.
- Modern Nvidia, AMD and Intel gpus are supported on both Windows and Linux. Macs may or may not work.
- Please use the latest Iris version. Optifine has some small bugs, but it should also mostly work.
